//
//  DisplayTool.h
//  LuaSanGuo
//
//  Created by 常胜 on 15/7/16.
//
//

#ifndef __LuaSanGuo__DisplayTool__
#define __LuaSanGuo__DisplayTool__

#include <stdio.h>
#include "cocos2d.h"

USING_NS_CC;

class DisplayTool{

public:
    static void graySprite(Node* sp, bool isGray);
    
};

#endif /* defined(__LuaSanGuo__DisplayTool__) */
