/**
 * The const defination for XPlayer.
 *
 *
 * @version 0.0.1
 *
 */

#ifndef _OnlineDefines_
#define _OnlineDefines_







#endif//_OnlineDefines_