#include <process.h>

class Thread {

};