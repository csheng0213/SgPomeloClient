#ifndef __FORWARDDATA_H__
#define __FORWARDDATA_H__


#pragma pack(push, 1)

enum EGosType
{
	ItemTrack = 1,
	Upgrade = 2,
	GainExp = 3,
	MoneyTrack = 4,
	GoldTrack = 5,
};


#pragma pack(pop)

#endif